class API{
  static const String server = "http://192.168.11.133";

}