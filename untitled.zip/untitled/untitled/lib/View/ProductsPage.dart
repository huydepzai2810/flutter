import 'package:flutter/material.dart';

class ProductsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Nội dung Sản phẩm'));
  }
}