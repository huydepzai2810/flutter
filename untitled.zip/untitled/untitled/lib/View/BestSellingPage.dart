// BestSellingPage.dart
import 'package:flutter/material.dart';

class BestSellingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Nội dung Bán chạy'));
  }
}
